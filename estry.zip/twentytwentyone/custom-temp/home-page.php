<?php /*Template Name: Home page*/ 
get_header();
 ?>

 <!-- Hero/Intro Slider Start -->
    <div class="section">
        <div class="hero-slider">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="hero-slide-item swiper-slide">
					<?php if( have_rows('hero_slide_item') ):
					
					while( have_rows('hero_slide_item') ) : the_row();
						
					 $slider_image = get_sub_field('slider_image');
					  ?>
                        <div class="hero-slide-bg">
                            <img src="<?php echo  $slider_image; ?>" alt="Slider Image" />
                        </div>

                    <?php endwhile; endif; ?>
                        <!-- Hero Slider Bg image End -->

                        <!-- Hero Slider Content Start -->
                        <div class="container">
                            <div class="hero-slide-content">
                                <h2 class="title">
                                <?php while( have_rows('hero_slide_item') ) : the_row();
                                $tit = get_sub_field('hero_slide_content'); ?>
                                <?php echo $tit; ?>
                                <?php endwhile; ?>
                                </h2>
                                <p>Up to 70% off selected Product</p>
                                <a href="shop-grid.html" class="btn btn-lg btn-primary btn-hover-dark">Shop Now</a>
                            </div>
                        </div>
                        <!-- Hero Slider Content End -->
                    </div>
                    <!-- Hero Slider Item End -->


                </div>

                <!-- Swiper Pagination Start -->
                <div class="swiper-pagination d-md-none"></div>
                <!-- Swiper Pagination End -->

                <!-- Swiper Navigation Start -->
                <div class="home-slider-prev swiper-button-prev main-slider-nav d-md-flex d-none"><i class="pe-7s-angle-left"></i></div>
                <div class="home-slider-next swiper-button-next main-slider-nav d-md-flex d-none"><i class="pe-7s-angle-right"></i></div>
                <!-- Swiper Navigation End -->

            </div>
        </div>
    </div>
    <!-- Hero/Intro Slider End -->

     <!-- Banner Section Start -->
    <div class="section section-margin">
        <div class="container">

            <!-- Banners Start -->
            <div class="row mb-n6">
                <!-- Banner Start -->
                <?php while(have_rows('banner_image_section')): the_row(); 
                      $ban = get_sub_field('banner_image');
                      $sub_title = get_sub_field('sub_title');
                      $get_offer = get_sub_field('get_offer');
                      $shoplink = get_sub_field('shop_grid_link'); ?>
                <div class="col-lg-4 col-md-6 col-12 mb-6">
                    <div class="banner" data-aos="fade-up" data-aos-delay="300">
                        <div class="banner-image">
                            <a href=""><img src="<?php echo $ban; ?>" alt=""></a>
                        </div>
                        <div class="info">
                            <div class="small-banner-content">
                                <h4 class="sub-title"><?php echo $sub_title; ?></h4>
                                <h3 class="title"> <?php echo $get_offer; ?></h3>
                                <a href="<?php echo $shoplink; ?>" class="btn btn-dark btn-sm">Shop Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile;?>
                <!-- Banner End -->
            </div>
            <!-- Banners End -->
        </div>
    </div>
    <!-- Banner Section End -->

      <!-- Feature Section Start -->
    <div class="section">
        <div class="container">
            <div class="feature-wrap">
                <div class="row row-cols-lg-4 row-cols-xl-auto row-cols-sm-2 row-cols-1 justify-content-between mb-n5">
                        <?php while(have_rows('feature_wrap_section')):the_row(); ?>
                        <div class="feature">
                    <!-- Feature Start -->
                    <div class="col mb-5" data-aos="fade-up" data-aos-delay="300">
                            <div class="icon text-primary align-self-center">
                                <img src="<?php the_sub_field('feature_icon'); ?>" alt="Feature Icon">
                            </div>
                            <div class="content">
                                <?php the_sub_field('feature_content');?>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>


                   
                </div>
            </div>
        </div>
    </div>
    <!-- Feature Section End -->
    <?php
    $args = array(
    'post_type'    => 'product',
    'showposts'    => -1,
    'post_status'  => 'publish',
    'parent' => 0,
    'exclude' => 15,
    'hide_empty' => true,
    'tax_query' => array(
        'taxonomy' => 'product_cat',
        'field'    => 'slug',
        'terms'    => array( 'best-sellers', 'new-arrivals', 'sale-items' ),
        'operator' => 'NOT IN',
    ),
); 
$query = new WP_Query( $args );
?>

     <!-- Product Section Start -->
    <div class="section section-padding mt-0">
        <div class="container">
            <!-- Section Title & Tab Start -->
            <div class="row">
                <!-- Tab Start -->
                <div class="col-12">

                    <ul class="product-tab-nav nav justify-content-center mb-10 title-border-bottom mt-n3">
                         <?php  $terms = get_terms( 'product_cat', $args);
                         foreach ( $terms as $term ) { 
                            ?>
                        <li class="nav-item" data-aos="fade-up" data-aos-delay="400">
                            <a class="nav-link mt-3" data-bs-toggle="tab" href="#tab-<?php echo $term->slug; ?>"><?php echo $term->name; ?></a></li>
                    <?php  } ?>
                    </ul>
                </div>
                <!-- Tab End -->
            </div>
            <div class="row">
                <div class="col">
                    <div class="tab-content position-relative">
                          <?php  $terms = get_terms( 'product_cat', $args);
                         $i = 1;
                         foreach ( $terms as $term ) { 
                            ?>
                        <div class="tab-pane fade show <?php if($i==1){ echo ' active';} ?>" id="tab-<?php echo $term->slug; ?>">
                            <?php $i++; } ?>
                            <div class="product-carousel">
                                <div class="swiper-container">
                                    <div class="swiper-wrapper mb-n10">

                                        <!-- Product Start -->
                                        <?php if ( $query->have_posts() ) {
                                           while ( $query->have_posts() ):  $query->the_post();
                                             global $product;
                                            $rating_count = $product->get_rating_count();
                                            $review_count = $product->get_review_count();
                                            $average      = $product->get_average_rating();
                                          ?>
                                        <div class="swiper-slide product-wrapper">

                                            <!-- Single Product Start -->
                                            <div class="product product-border-left mb-10" data-aos="fade-up" data-aos-delay="300">
                                                <div class="thumb">
                                                <a href="<?php the_permalink(); ?>"> <?php  woocommerce_template_loop_product_thumbnail(); ?>
                                                    <div class="actions action wishlist">
                                                        <?php echo do_shortcode('[yith_wcwl_add_to_wishlist]'); ?>
                                                        <a href="#" class="action quickview" data-bs-toggle="modal" data-bs-target="#exampleModalCenter"><i class="pe-7s-search"></i></a>
                                                        <a href="#" class="action compare"><i class="pe-7s-shuffle"></i></a>
                                                       
                                                    </div>
                                                </div>
                                                <div class="content">
                                                    <h4 class="sub-title"><a href="<?php the_permalink();?>"><?php echo $product->get_categories();?></a></h4>
                                                    <h5 class="title"><?php the_title(); ?></h5>
                                                     <span class="ratings">
                                                    <?php woocommerce_template_loop_rating(); 
                                                    if ( $rating_count > 0 ) : 
                                                          ?>
                                                          <span class="rating-num">(<?php echo $review_count; ?>)</span>
                                                        <?php endif; ?>
                                                    </span>
                                                     <span class="price">
                                                          <?php woocommerce_template_loop_price(); ?>
                                                    </span>
                                                   <?php  echo "<a href='" . $product->add_to_cart_url() ."' class='btn btn-sm btn-outline-dark btn-hover-primary' >add to cart</a>"; ?>
                                                   
                                                 
                                                </div>
                                            </div>
                                            <!-- Single Product End -->

                                            
                                        </div>
                                        <?php  endwhile; } wp_reset_postdata();?>
                                   
                                       

                                    </div>

                                    <!-- Swiper Pagination Start -->
                                    <div class="swiper-pagination d-md-none"></div>
                                    <!-- Swiper Pagination End -->

                                    <!-- Next Previous Button Start -->
                                    <div class="swiper-product-button-next swiper-button-next swiper-button-white d-md-flex d-none"><i class="pe-7s-angle-right"></i></div>
                                    <div class="swiper-product-button-prev swiper-button-prev swiper-button-white d-md-flex d-none"><i class="pe-7s-angle-left"></i></div>
                                    <!-- Next Previous Button End -->
                                </div>
                            </div>
                        </div>
                </div>
            </div>
            <!-- Products Tab End -->
        </div>
    </div>
    <!-- Product Section End -->


   <!-- Banner Fullwidth Start -->
    <div class="section section-padding mt-0 overflow-hidden">
    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-12" data-aos="fade-up" data-aos-delay="300">
                    <div class="banner">
                        <div class="banner-image">
                            <a href="<?php the_field('banner_image_link'); ?>"><img src="<?php the_field('banner_image'); ?>" alt="Banner"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- Banner Fullwidth End -->

 <!-- Product Deal Section Start -->
    <div class="section section-padding mt-0 overflow-hidden">
        <div class="container">
            <!-- Section Title & Tab Start -->
            <div class="row">
                <!-- Tab Start -->
                <div class="col-12">
                    <div class="section-title-produt-tab-wrapper">
                        <div class="section-title m-0" data-aos="fade-right" data-aos-delay="300">
                            <h1 class="title">Daily Deals</h1>
                        </div>
                        <ul class="product-tab-nav nav mt-n3" data-aos="fade-left" data-aos-delay="300">
                             <?php  $terms = get_terms( 'product_cat', $args);
                         foreach ( $terms as $term ) { 
                            ?>
                        <li class="nav-item" data-aos="fade-up" data-aos-delay="400">
                            <a class="nav-link mt-3" data-bs-toggle="tab" href="#product-<?php echo $term->slug; ?>"><?php echo $term->name; ?></a></li>
                    <?php  } ?>
                        </ul>
                    </div>
                </div>
                <!-- Tab End -->
            </div>
            <!-- Section Title & Tab End -->

            <!-- Products Tab Start -->
            <div class="row">
                <div class="col">
                    <div class="tab-content position-relative">
                         <?php  $terms = get_terms( 'product_cat', $args);
                         $i = 1;
                         foreach ( $terms as $term ) { 
                            ?>
                        <div class="tab-pane fade show <?php if($i==1){ echo ' active';} ?>" id="product-<?php echo $term->slug; ?>">
                              <?php $i++; } ?>
                            <div class="product-deal-carousel">
                                <div class="swiper-container">
                                    <div class="swiper-wrapper">
                                        <!-- Product Start -->
                                            <?php 
                                           /* echo "<pre>";
                                            print_r($query);*/

                                            if ( $query->have_posts() ) {
                                            while ( $query->have_posts() ):  $query->the_post();
                                            global $product;
                                            $rating_count = $product->get_rating_count();
                                            $review_count = $product->get_review_count();
                                            $average      = $product->get_average_rating();

                                            ?>
                                        <div class="swiper-slide product-wrapper" data-aos="fade-right" data-aos-delay="600">
                                            <!-- Single Product Deal Start -->
                                            <div class="product single-deal-product product-border-left">
                                                <div class="thumb">
                                                    <a href="<?php the_permalink(); ?>" class="image">
                                                       <?php  woocommerce_template_loop_product_thumbnail(); ?>
                                                    </a>
                                                    <span class="badges">
                                                            <span class="sale">-30%</span>
                                                    </span>
                                                </div>
                                                <div class="content">
                                                    <p class="inner-desc">Hurry Up! Offer Ends In:</p>
                                                    <div class="countdown-area">
                                                         <?php 
                                                          echo do_shortcode('[tminus t="+1 hour 45 minutes"/]'); //dynamic_sidebar('countdown-1');?>
                                                    </div>
                                                    <h4 class="sub-title"><a href="<?php the_permalink();?>"><?php echo $product->get_categories();?></a></h4>
                                                    <h5 class="title"><?php the_title(); ?></h5>
                                                    <span class="ratings">
                                                    <?php woocommerce_template_loop_rating();  ?> </span>
                                                    <span class="rating-wrap">
                                                    <span class="rating-num"><?php if ( $rating_count > 0 ) :?> 
                                                          (<?php echo $review_count; ?>) <?php endif; ?> </span>
                                                    </span>
                                                    <span class="price">
                                                            <?php $price = get_post_meta( get_the_ID(), '_regular_price', true);
                                                            if($price) { ?> 

                                                            <span class="new">$<?php echo $price; ?></span>
                                                        <?php } ?>

                                                            <?php  $sale = get_post_meta( get_the_ID(), '_sale_price', true); 
                                                            if( $sale){?>
                                                    <span class="old">$<?php echo $sale; ?></span>
                                                <?php } ?>

                                                    </span>
                                                    <?php  echo "<a href='" . $product->add_to_cart_url() ."' class='btn btn-sm btn-outline-dark btn-hover-primary' >add to cart</a>"; ?>
                                                </div>
                                            </div>
                                            <!-- Single Product Deal End -->
                                        </div>
                                             <?php  endwhile; } wp_reset_postdata();?>
                                        <!-- Product End -->


                                    </div>

                                    <!-- Swiper Pagination Start -->
                                    <div class="swiper-pagination d-md-none"></div>
                                    <!-- Swiper Pagination End -->

                                    <!-- Next Previous Button Start -->
                                    <div class="swiper-product-deal-next swiper-button-next swiper-button-white d-md-flex d-none"><i class="pe-7s-angle-right"></i></div>
                                    <div class="swiper-product-deal-prev swiper-button-prev swiper-button-white d-md-flex d-none"><i class="pe-7s-angle-left"></i></div>
                                    <!-- Next Previous Button End -->
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
            <!-- Products Tab End -->
        </div>

    </div>
    <!-- Product Deal Section End -->

 <!-- Banner Section Start -->
  <div class="section section-padding mt-0 overflow-hidden">
    <div class="section">
        <div class="container">

            <!-- Banners Start -->
            <div class="row mb-n6 overflow-hidden">
                <!-- Banner Start -->
                <?php if(have_rows('banner_section_repiter')):
                    while(have_rows('banner_section_repiter')): the_row();?>
                <div class="col-md-6 col-12 mb-6" data-aos="fade-right" data-aos-delay="300">
                    <div class="banner">
                        <div class="banner-image">
                            <a href="shop-grid.html"><img src="<?php the_sub_field('banner_section_img');?>" alt="Banner Image"></a>
                        </div>
                        <div class="info">
                            <div class="small-banner-content">
                                <h4 class="sub-title"><?php the_sub_field('sub_title_prod');?></h4>
                                <h3 class="title"><?php the_sub_field('title_prodct');?></h3>
                                <a href="<?php the_sub_field('banner_section_img_link'); ?>" class="btn btn-primary btn-hover-dark btn-sm">Shop Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; endif;?>

            </div>
            <!-- Banners End -->
        </div>
    </div>
</div>
    <!-- Banner Section End -->



    <!-- Product List Start -->
    <div class="section section-padding">
        <div class="container">
            <div class="row mb-n8">
                <div class="col-md-6 col-lg-4 col-12 mb-8" data-aos="fade-up" data-aos-delay="300">
                    <!-- Product List Title Start -->
                    <div class="product-list-title">
                        <h2 class="title pb-3 mb-0">Best Offer</h2>
                        <span></span>
                    </div>
                    <!-- Product List Title End -->
<?php
    $args = array(
    'post_type'    => 'product',
    'showposts'    => 3,
    'post_status'  => 'publish',
    'parent' => 0,
    'exclude' => 15,
    'hide_empty' => true,
    'tax_query' => array(
        'taxonomy' => 'product_cat',
        'field'    => 'slug',
        'terms'    => 'best-sellers',
        'operator' => 'NOT IN',
    ),
); 
$query1 = new WP_Query( $args );
?>
                    <!-- Product List Carousel Start -->
                    <div class="product-list-carousel">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">

                                <!-- Product List Wrapper Start -->

                                 <div class="swiper-slide product-list-wrapper mb-n6">
                                <?php if ( $query1->have_posts() ) {
                                while ( $query1->have_posts() ):  $query1->the_post(); 
                                     global $product;
                                            $rating_count = $product->get_rating_count();
                                            $review_count = $product->get_review_count();
                                            $average      = $product->get_average_rating(); ?>

                                    <!-- Single Product List Start -->
                                    <div class="single-product-list product-hover mb-6">

                                        <div class="thumb">
                                            <?php echo get_the_post_thumbnail( $post_id, 'medium' );?>
                                        </div>
                                        <div class="content">
                                            <h5 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                            <span class="price">
                                                            <?php $price = get_post_meta( get_the_ID(), '_regular_price', true);
                                                            if($price) { ?> 

                                                            <span class="new">$<?php echo $price; ?></span>
                                                        <?php } ?>

                                                            <?php  $sale = get_post_meta( get_the_ID(), '_sale_price', true); 
                                                            if( $sale){?>
                                                    <span class="old">$<?php echo $sale; ?></span>
                                                <?php } ?>

                                                </span>
                                            <span class="ratings">
                                                    
                                                        <?php woocommerce_template_loop_rating();  ?> 
                                            </span>
                                            <span class="rating-num"> <?php if ( $rating_count > 0 ) :?> 
                                                          (<?php echo $review_count; ?>) <?php endif; ?> </span>
                                            </span>
                                        </div>
                                    </div>
                                    <!-- Single Product List End -->


                            <?php endwhile; } ?>
                                </div>
                                <!-- Product List Wrapper End -->

                                <!-- Product List Wrapper Start -->
                                <div class="swiper-slide product-list-wrapper mb-n6">

                                    <!-- Single Product List Start -->
                                    <?php if ( $query1->have_posts() ) {
                                while ( $query1->have_posts() ):  $query1->the_post(); 
                                     global $product;
                                            $rating_count = $product->get_rating_count();
                                            $review_count = $product->get_review_count();
                                            $average      = $product->get_average_rating(); ?>

                                    <!-- Single Product List Start -->
                                    <div class="single-product-list product-hover mb-6">

                                        <div class="thumb">
                                            <?php echo get_the_post_thumbnail( $post_id, 'medium' );?>
                                        </div>
                                        <div class="content">
                                            <h5 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                            <span class="price">
                                                            <?php $price = get_post_meta( get_the_ID(), '_regular_price', true);
                                                            if($price) { ?> 

                                                            <span class="new">$<?php echo $price; ?></span>
                                                        <?php } ?>

                                                            <?php  $sale = get_post_meta( get_the_ID(), '_sale_price', true); 
                                                            if( $sale){?>
                                                    <span class="old">$<?php echo $sale; ?></span>
                                                <?php } ?>

                                                </span>
                                            <span class="ratings">
                                                    
                                                        <?php woocommerce_template_loop_rating();  ?> 
                                            </span>
                                            <span class="rating-num"> <?php if ( $rating_count > 0 ) :?> 
                                                          (<?php echo $review_count; ?>) <?php endif; ?> </span>
                                            </span>
                                        </div>
                                    </div>
                                    <!-- Single Product List End -->


                            <?php endwhile; } ?>
                                    <!-- Single Product List End -->     

                                </div>
                                <!-- Product List Wrapper End -->

                            </div>

                            <!-- Swiper Pagination Start -->
                            <!-- <div class="swiper-pagination d-md-none"></div> -->
                            <!-- Swiper Pagination End -->

                            <!-- Next Previous Button Start -->
                            <div class="swiper-product-list-next swiper-button-next"><i class="pe-7s-angle-right"></i></div>
                            <div class="swiper-product-list-prev swiper-button-prev"><i class="pe-7s-angle-left"></i></div>
                            <!-- Next Previous Button End -->

                        </div>
                    </div>
                    <!-- Product List Carousel End -->

                </div>
                <div class="col-md-6 col-lg-4 col-12 mb-8" data-aos="fade-up" data-aos-delay="500">
                    <!-- Product List Title Start -->
                    <div class="product-list-title">
                        <h2 class="title pb-3 mb-0">New Products</h2>
                        <span></span>
                    </div>
                    <!-- Product List Title End -->
<?php
    $args = array(
    'post_type'    => 'product',
     'offset'   => 5,
    'showposts'    => 3,
    'cat_name' => 'New Arrivals',
    'post_status'  => 'publish'
    

); 
$query2 = new WP_Query( $args );
?>
                    <!-- Product List Start -->
                    <div class="product-list-carousel-2">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">

                                <!-- Product List Wrapper Start -->
                                <div class="swiper-slide product-list-wrapper mb-n6">

                                   <?php if ( $query2->have_posts() ) {
                                while ( $query2->have_posts() ):  $query2->the_post(); 
                                     global $product;
                                            $rating_count = $product->get_rating_count();
                                            $review_count = $product->get_review_count();
                                            $average      = $product->get_average_rating(); ?>

                                    <!-- Single Product List Start -->
                                    <div class="single-product-list product-hover mb-6">

                                        <div class="thumb">
                                            <?php echo get_the_post_thumbnail( $post_id, 'medium' );?>
                                        </div>
                                        <div class="content">
                                            <h5 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                            <span class="price">
                                                            <?php $price = get_post_meta( get_the_ID(), '_regular_price', true);
                                                            if($price) { ?> 

                                                            <span class="new">$<?php echo $price; ?></span>
                                                        <?php } ?>

                                                            <?php  $sale = get_post_meta( get_the_ID(), '_sale_price', true); 
                                                            if( $sale){?>
                                                    <span class="old">$<?php echo $sale; ?></span>
                                                <?php } ?>

                                                </span>
                                            <span class="ratings">
                                                    
                                                        <?php woocommerce_template_loop_rating();  ?> 
                                            </span>
                                            <span class="rating-num"> <?php if ( $rating_count > 0 ) :?> 
                                                          (<?php echo $review_count; ?>) <?php endif; ?> </span>
                                            </span>
                                        </div>
                                    </div>
                                 <!-- Single Product List End -->
                            <?php endwhile; } ?>

                                </div>
                                <!-- Product List Wrapper End -->

                                <!-- Product List Wrapper Start -->
                                <div class="swiper-slide product-list-wrapper mb-n6">

                                    <?php if ( $query2->have_posts() ) {
                                while ( $query2->have_posts() ):  $query2->the_post(); 
                                     global $product;
                                            $rating_count = $product->get_rating_count();
                                            $review_count = $product->get_review_count();
                                            $average      = $product->get_average_rating(); ?>

                                    <!-- Single Product List Start -->
                                    <div class="single-product-list product-hover mb-6">

                                        <div class="thumb">
                                            <?php echo get_the_post_thumbnail( $post_id, 'medium' );?>
                                        </div>
                                        <div class="content">
                                            <h5 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                            <span class="price">
                                                            <?php $price = get_post_meta( get_the_ID(), '_regular_price', true);
                                                            if($price) { ?> 

                                                            <span class="new">$<?php echo $price; ?></span>
                                                        <?php } ?>

                                                            <?php  $sale = get_post_meta( get_the_ID(), '_sale_price', true); 
                                                            if( $sale){?>
                                                    <span class="old">$<?php echo $sale; ?></span>
                                                <?php } ?>

                                                </span>
                                            <span class="ratings">
                                                    
                                                        <?php woocommerce_template_loop_rating();  ?> 
                                            </span>
                                            <span class="rating-num"> <?php if ( $rating_count > 0 ) :?> 
                                                          (<?php echo $review_count; ?>) <?php endif; ?> </span>
                                            </span>
                                        </div>
                                    </div>
                                 <!-- Single Product List End -->
                            <?php endwhile; } ?>

                                </div>
                                <!-- Product List Wrapper End -->

                            </div>

                            <!-- Swiper Pagination Start -->
                            <!-- <div class="swiper-pagination d-md-none"></div> -->
                            <!-- Swiper Pagination End -->

                            <!-- Next Previous Button Start -->
                            <div class="swiper-product-list-next swiper-button-next"><i class="pe-7s-angle-right"></i></div>
                            <div class="swiper-product-list-prev swiper-button-prev"><i class="pe-7s-angle-left"></i></div>
                            <!-- Next Previous Button End -->
                        </div>
                    </div>
                    <!-- Product List End -->
                </div>
                <div class="col-md-6 col-lg-4 col-12 mb-8" data-aos="fade-up" data-aos-delay="700">
                    <!-- Product List Title Start -->
                    <div class="product-list-title">
                        <h2 class="title pb-3 mb-0">Best Sellers</h2>
                        <span></span>
                    </div>
                    <!-- Product List Title End -->
<?php
$args = array(
'post_type'    => 'product',
'offset'   => 6,
'showposts'    => 3,
'cat_name' => 'Sale Items',
'post_status'  => 'publish'

); 
$query3 = new WP_Query( $args );
?>
    
                    <!-- Product List Start -->
                    <div class="product-list-carousel-3">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">

                                <!-- Product List Wrapper Start -->
                                <div class="swiper-slide product-list-wrapper mb-n6">
                                <?php if ( $query3->have_posts() ) {
                                while ( $query3->have_posts() ):  $query3->the_post(); 
                                global $product;
                                $rating_count = $product->get_rating_count();
                                $review_count = $product->get_review_count();
                                $average      = $product->get_average_rating(); ?>

                                    <!-- Single Product List Start -->
                                    <!-- Single Product List Start -->
                                    <div class="single-product-list product-hover mb-6">

                                        <div class="thumb">
                                            <?php echo get_the_post_thumbnail( $post_id, 'medium' );?>
                                        </div>
                                        <div class="content">
                                            <h5 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                            <span class="price">
                                                            <?php $price = get_post_meta( get_the_ID(), '_regular_price', true);
                                                            if($price) { ?> 

                                                            <span class="new">$<?php echo $price; ?></span>
                                                        <?php } ?>

                                                            <?php  $sale = get_post_meta( get_the_ID(), '_sale_price', true); 
                                                            if( $sale){?>
                                                    <span class="old">$<?php echo $sale; ?></span>
                                                <?php } ?>

                                                </span>
                                            <span class="ratings">
                                                    
                                                        <?php woocommerce_template_loop_rating();  ?> 
                                            </span>
                                            <span class="rating-num"> <?php if ( $rating_count > 0 ) :?> 
                                                          (<?php echo $review_count; ?>) <?php endif; ?> </span>
                                            </span>
                                        </div>
                                    </div>
                                 <!-- Single Product List End -->
                            <?php endwhile; } ?>

                                </div>

                                </div>
                                <!-- Product List Wrapper End -->

                            </div>

                            <!-- Swiper Pagination Start -->
                            <!-- <div class="swiper-pagination d-md-none"></div> -->
                            <!-- Swiper Pagination End -->

                            <!-- Next Previous Button Start -->
                            <div class="swiper-product-list-next swiper-button-next"><i class="pe-7s-angle-right"></i></div>
                            <div class="swiper-product-list-prev swiper-button-prev"><i class="pe-7s-angle-left"></i></div>
                            <!-- Next Previous Button End -->

                        </div>
                    </div>
                    <!-- Product List End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Product List End -->
<?php $args = array(
    'post_type'    => 'product',
    'showposts'    => -1,
    'post_status' => 'publish'
);

$pro = new WP_Query($args);
    ?>

      <!-- Brand Logo Start -->
    <div class="section">
        <div class="container">
            <div class="border-top">
                <div class="row">
                    <div class="col-12">
                        <!-- Brand Logo Wrapper Start -->
                        <div class="brand-logo-carousel">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">
                                    <?php if($pro->have_posts()):
                                        while($pro->have_posts()): $pro->the_post();?>

                                    <!-- Single Brand Logo Start -->
                                    <div class="swiper-slide single-brand-logo" data-aos="fade-up" data-aos-delay="300">

                                        <a href="<?php the_permalink();?>"> <?php echo get_the_post_thumbnail( $post_id, array( 100, 100) );?></a>
                                    </div>
                                <?php endwhile; endif; ?>
                                    <!-- Single Brand Logo End -->
                                </div>
                            </div>
                        </div>
                        <!-- Brand Logo Wrapper End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Brand Logo End -->
 <?php get_footer();?>